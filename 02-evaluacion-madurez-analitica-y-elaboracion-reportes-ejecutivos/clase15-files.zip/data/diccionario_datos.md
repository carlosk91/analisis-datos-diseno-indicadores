# Diccionario de datos — NovaCrédito (sintético)

**Integridad:** CSV con encabezados, codificación UTF-8 y coma como delimitador. No hay duplicados en sus llaves declaradas. Todos los números son inventados para fines docentes y **no representan clientes ni resultados reales**.

## `adquisicion_mensual.csv`

**Grano:** 1 registro por (`mes`, `canal`). **Cobertura:** abril–septiembre 2026. 18 registros.

| Campo | Tipo | Significado |
|---|---|---|
| `mes` | fecha ISO | Primer día del mes de adquisición. |
| `canal` | texto | Social, Búsqueda o Referidos. |
| `gasto_mxn` | entero | Gasto de adquisición del canal atribuible a ese mes, MXN. |
| `solicitudes` | entero | Solicitudes atribuidas al canal en el mes. |
| `altas` | entero | Clientes activados/altas atribuidas al canal en el mes. |
| `margen_12m_estimado_por_alta_mxn` | entero | **Proyección de modelo** del margen acumulado esperado durante los 12 meses posteriores a cada alta, ajustado en la simulación por pérdidas de crédito previstas y costos variables, **antes de gastos de adquisición**. No es ingreso ni utilidad realizada. |

**Derivaciones:** `cac_mxn = gasto_mxn / altas`; `tasa_conversion = altas / solicitudes`; `margen_total_12m_estimado = altas × margen_12m_estimado_por_alta_mxn`. Para comparar más de un mes, **sumar numerador y denominador** antes de calcular CAC. El margen futuro modelado **no está conciliado con contabilidad**, ni constituye efecto incremental causal.

## `calidad_cohortes_maduras.csv`

**Grano:** 1 registro por (`cohorte`, `canal`). **Cobertura:** 2025 Q3–Q4. 6 registros. **Población distinta a la de la tabla 2026.**

| Campo | Tipo | Significado |
|---|---|---|
| `cohorte` | texto | Trimestre de originación de clientes, suficientemente antiguo para observar la métrica definida. |
| `canal` | texto | Canal atribuido. |
| `clientes_maduros_n` | entero | Denominador de la cohorte observada. |
| `clientes_90dpd_n` | entero | Clientes que llegaron a 90+ días de mora bajo observación de esta cohorte. |

**Derivación:** `tasa_mora_90d = suma(clientes_90dpd_n) / suma(clientes_maduros_n)`; no promediar tasas pequeñas sin sus denominadores. La comparación no controla composición de clientes, edad de cartera ni cambios de política. Es una **señal histórica**, no una estimación causal de la calidad incremental.

## `capacidad_operativa.csv`

**Grano:** 1 fila por `canal`. **Horizonte:** Q4 2026. 3 registros.

| Campo | Tipo | Significado |
|---|---|---|
| `altas_incrementales_max_q4` | entero | Estimación interna preliminar de máximas altas adicionales que podrían procesarse en Q4, **sin validación**. |
| `nivel_validacion` | texto | Estado de confianza operativa cualitativo. |
| `nota` | texto | Restricción y pendiente de validación. |

**No confundir** capacidad incremental estimada con demanda real, retorno incremental o autorización del presupuesto.

## `supuestos_escenarios.csv`

**Grano:** 1 fila por escenario subjetivo, no probabilístico. Tres escenarios: conservador, base y optimista.

| Campo | Tipo | Significado |
|---|---|---|
| `escenario` | texto | Nombre descriptivo de una combinación hipotética. |
| `cac_marginal_ref_sup_mxn` | entero | Supuesto **no observado** de gasto adicional por nueva alta marginal en Referidos. |
| `margen_12m_ref_sup_mxn` | entero | Supuesto del margen futuro modelado por alta marginal de Referidos, neto de pérdidas esperadas en la simulación, antes de costo de adquisición. |
| `cac_marginal_social_sup_mxn` | entero | Supuesto de CAC marginal de Social, **no identificado** del CAC promedio. |
| `margen_12m_social_sup_mxn` | entero | Supuesto de margen futuro de alta marginal de Social. |
| `cupo_ref_adicional_sup_n` | entero | Altas adicionales permitidas según la capacidad hipotética del escenario, sin exceder la estimación Q4 preliminar. |
| `costo_implementacion_sup_mxn` | entero | Supuesto de costo adicional de personal, medición y control del piloto, **separado** del presupuesto transferido. |

**Modelo docente:** traslado efectivo = `min(presupuesto máximo, cupo × CAC marginal referidos)`; contribución diferencial estimada a 12 meses = `(traslado / CAC ref × margen ref) − (traslado / CAC social × margen social) − costo implementación`. Se compara el **mismo gasto de marketing** en ambas ramas, que se cancela, sin valorar otros costos ni la incertidumbre distributiva. **No** es forecast validado, intervalo de confianza, causalidad ni recomendación óptima.

## Limitaciones deliberadas del ejercicio

- No existe medición del **CAC marginal realizado** bajo reasignación.
- No hay prueba de incrementalidad o test con contrafactual.
- Calidad histórica 2025 y adquisición reciente 2026 **no son cohortes homologadas**.
- Capacidad no confirmada, márgenes modelados y escenarios no probabilísticos.
- No se incluye curva de cobranza, calendario de flujo de efectivo, fondeo, costos fijos adicionales ni capital económico: evita prometer rentabilidad contable o ROI financiero realizado.
